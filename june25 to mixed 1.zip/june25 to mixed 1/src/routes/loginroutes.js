const expresss=require("express");

const loginrouter=expresss.Router();

function routerlogin(nav){
    loginrouter.get("/",function(req,res){
        res.render("login",{
            nav,
            title:'library'
        });
    });
    return loginrouter;
}
module.exports=routerlogin;