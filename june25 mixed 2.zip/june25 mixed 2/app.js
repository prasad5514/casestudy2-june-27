//express is backend frame work(we can add module(javascript library) to our project,module will contan packages),API is a inter mediatery between client and server,express is used to built API,express takes request from front end and serves back data in json format

const expresss=require("express");


const app=expresss();

const nav=[
    {link:'/books',name:'books'},
    {link:'/authers',name:'authers'},
    {link:'/login',name:'login'},
    {link:'/signup',name:'sign up'},
    {link:'/admin',name:'add book'},
    {link:'/adminaut',name:'add auther'}
   ];

const booksrouter=require("./src/routes/booksroutes")(nav)
const loginrouter=require("./src/routes/loginroutes")(nav)
const signuprouter=require("./src/routes/signuproutes")(nav)
const authersrouter=require("./src/routes/authersroutes")(nav)
const adminrouter=require("./src/routes/adminroutes")(nav)
app.use(expresss.urlencoded({extended:true})); //middleware for using post method
const adminrouteraut=require("./src/routes/adminroutesaut")(nav)

app.use(expresss.static('./public'));  //to add css file into project,we have to use middle way function express.static

app.set('view engine','ejs');
// app.set('views','./src/views');
app.set('views',__dirname+'/src/views');
app.use('/books',booksrouter);
app.use('/login',loginrouter);
app.use('/signup',signuprouter);
app.use('/authers',authersrouter);
app.use('/admin',adminrouter);
app.use('/adminaut',adminrouteraut);


app.get("/",function(req,res){         //for our first page , index.ejs
    // res.send("hello world!");
    // res.sendFile("/src/views/index.html");//wrong,path is incomplete//npm init for creating package.json,,../,,
    // res.sendFile(__dirname+"/src/views/index.html")

    //res.render("index",{books:['book1','book2'],title:'library'})

    res.render("indexass11",
    {
        nav,
        title:'libraryy'

    });
});


                           
 app.listen(5021);            //localhost:5000=127.0.0.1:5000