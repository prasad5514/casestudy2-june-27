//this file is to connect db with server
const mongoose=require("mongoose");  //accessing package 

mongoose.connect('mongodb://localhost:27017/library'); //database connction,library is name of db that going to makes,mongoose is middleware

//mongoose.connect('mongodb://localhost:27017/library', { useNewUrlParser: true }); //from net half error gone


const schema=mongoose.Schema;  //schema definision
//construter
const bookschema=new schema({
    title:String,
    auther:String,
    genre:String,
    image:String
});
//model creation,need to embed this schema inside a model,each and every model will be intance of document or each instance model will be document 
var bookdatae=mongoose.model("bookdata",bookschema); //(collection name)bookdata will become bookdatas in db
//the data is passed from the adminroutes to the database viabookdatae,bookdatae is the link for the database
const autschema=new schema({
    name:String,
    birthplace:String,
    native:String,
    image:String
});
var autdatae=mongoose.model("autdata",autschema);

module.exports=bookdatae;
module.exports=autdatae;