const expresss=require("express");

const booksrouter=expresss.Router();
//const booksrouter2=expresss.Router();
const bookdatafa=require("../model/bookdatafile");

function router(nav){
    // var books=[
    //     {
    //         title:"tom and jerry",
    //         auther:"joseph barbera",
    //         genre:"cartoon",
    //         img:"tom.jpeg"      // /images/tom.jpeg
    //     },
    //     {
    //         title:"harry potter",
    //         auther:"j k rowling",
    //         genre:"fantasy",
    //         img:"harry.jpeg"
    //     },
    //     {
    //         title:"pathumayuda adu",
    //         auther:"vykom m basheer",
    //         genre:"drama",
    //         img:"basheer.jpeg"
    //     }
    // ]
    // booksrouter.get("/",function(req,res){      // slash means plain or plain text   /books no need
    // //app.get("/books",function(req,res){        //we are not using methode, bacause this is confusing,the second method is in line.4(initiation like)
    //     res.render("books",          //this is books.ejs file
    //     {
    //         // nav:[{link:'/books',name:'books'},{link:'/authers',name:'authers'}],
    //         nav,
    //         title:'libraryy',
    //         books        //no need of semicolon i think,this is book array
    //     });
    // }); 
    booksrouter.get("/",function(req,res){
        bookdatafa.find()    //findmany not working
        .then(function(books){            //whatever the findfuction will be saved in books,document from db will store in books
            res.render("books",{
                nav,
                title:"libraryy",
                books
            });
        });
    });
    
    // booksrouter.get("/single",function(req,res){
    //     res.send("hey iam single bookk");
    // });
    // booksrouter2.get("/",function(req,res){
    //     res.render("login",{
    //         nav,
    //         title:'library'
    //     });
    // });
    booksrouter.get("/:id2",function(req,res){
        const id3=req.params.id2
        bookdatafa.findOne({_id:id3})
        .then(function(bookk){
            res.render("book",{
            
                nav,
                title:'libraryy',
                bookk
            });
        });

        })
       
    
   

    //  booksrouter.get("/login",function(req,res){
    //      res.send("hello");
    //  });
    return booksrouter;
    //return booksrouter2,booksrouter;
    //return booksrouter2;

}

module.exports=router;         //two in one solution
// module.exports=booksrouter;