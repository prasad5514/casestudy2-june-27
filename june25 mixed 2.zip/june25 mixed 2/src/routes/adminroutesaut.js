const expresss=require("express");

const adminrouteraut=expresss.Router();
//const bookdataeaut=require("../model/bookdatafileaut");
const autdatae=require("../model/bookdatafile");

function router(nav){
    adminrouteraut.get("/",function(req,res){
        //res.send("iam added")
        res.render("addauther",{
            nav,
            title:"library"
        })
    })
    //adminrouter.get("/add",function(req,res){
        adminrouteraut.post("/addaut",function(req,res){
         //res.send("iam added")
        var itemaut={
            name:req.body.name,   //title:req.query.title,insted of query we have to use body in POST method because we are accessing from body not from (url)qery parameter 
            birthplace:req.body.birthplace,
            native:req.body.native,
            image:req.body.image
        }
        var bookaut=autdatae(itemaut);
        bookaut.save();  //saving to the database
        res.redirect("/authers")   //redircting to books page like nav bar in html
        
    })
    return adminrouteraut;

}
module.exports=router;

