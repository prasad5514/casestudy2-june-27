const expresss=require("express");

const adminrouteraut=expresss.Router();
//const bookdataeaut=require("../model/bookdatafileaut");
const autdatae=require("../model/autdatafile");

function router(nav){
    adminrouteraut.get("/",function(req,res){
        //res.send("iam added")
        res.render("addauther",{
            nav,
            title:"library"
        })
    })
    //adminrouteraut.get("/addauther",function(req,res){
        adminrouteraut.post("/addauther",function(req,res){
         //res.send("iam aut added")
        var itemaut={
            name:req.body.name,   //title:req.query.title,insted of query we have to use body in POST method because we are accessing from body not from (url)qery parameter 
            birthplace:req.body.birthplace,
            native:req.body.native,
            image:req.body.image
        }
        var aut=autdatae(itemaut);
        aut.save();  //saving to the database
        res.redirect("/authers")   //redircting to books page like nav bar in html
        
    })
    return adminrouteraut;

}
module.exports=router;

