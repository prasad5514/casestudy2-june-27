const expresss=require("express");

const authersrouter=expresss.Router();
const autdatafa=require("../model/bookdatafile");

function routerauthers(nav){

    var autdet=[
        {
            name:"joseph barbera",
            birthplace:"america",
            native:"london",
            img:"barbera.jpeg"
        },
        {
            name:"jk rowling",
            birthplace:"england",
            native:"cuba",
            img:"jkrowling.jpeg"
        },
        {
            name:"vykam muhammed basheer",
            birthplace:"kottyam",
            native:"vykam",
            img:"bhasher.jpeg"
        }
    ]

    authersrouter.get("/",function(req,res){
        //res.send("autheradded")
        //autdatafa.find()
        //.then(function(auts){
            res.render("authers",{
                nav,
                title:'authers',
                //auts
                autdet
            });
        // })
    });

    authersrouter.get("/:id",function(req,res){
        //authersrouter.get("/ReadMore",function(req,res){
        //res.send("iam added")
        const id=req.params.id
        //autdatafa.findOne({_id:id})
        //.then(function(autt){
            res.render("auther",{
                nav,
                title:'libraryy',
                autt:autdet[id]
            });
       // });
        
    });

    // authersrouter.get("/ReadMore",function(req,res){
    //     res.send("readmore ok")

    // })

    return authersrouter;
}
module.exports=routerauthers;

// <%=for(i=0;i<autdet.length;i++){%>
// <h3><%=autdet[i].name%></h3>

// <%}%>