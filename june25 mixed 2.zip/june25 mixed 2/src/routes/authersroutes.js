const expresss=require("express");

const authersrouter=expresss.Router();
const autdatafa=require("../model/autdatafile")

function routerauthers(nav){

    // var autdet=[
    //     {
    //         name:"joseph barbera",
    //         birthplace:"america",
    //         native:"london",
    //         img:"barbera.jpeg"
    //     },
    //     {
    //         name:"jk rowling",
    //         birthplace:"england",
    //         native:"cuba",
    //         img:"jkrowling.jpeg"
    //     },
    //     {
    //         name:"vykam muhammed basheer",
    //         birthplace:"kottyam",
    //         native:"vykam",
    //         img:"bhasher.jpeg"
    //     }
    // ]

    authersrouter.get("/",function(req,res){
        autdatafa.find()
        .then(function(autdet){   //name of aaray in the forloop of athers page
            //res.send("autheradded")
        res.render("authers",{
            nav,
            title:'authers',
            autdet
        });

        })
        
    });

    authersrouter.get("/delete/:id4",function(req,res){
        //res.send("deleted")
        const id5=req.params.id4
    //bookdatafa.findOneAndDelete({_id:id5})
    autdatafa.findOneAndDelete()
    .then(function(aut){
        //res.render("authers",{
            res.redirect("/authers")
        //     nav,
        //     title:"libraryy",
        //     aut
        // });
       })
   })

    authersrouter.get("/:id2",function(req,res){
        //authersrouter.get("/ReadMore",function(req,res){
        //res.send("iam added")
        const id3=req.params.id2
        autdatafa.findOne({_id:id3})
        .then(function(autt){
            res.render("auther",{
                nav,
                title:'libraryy',
                autt
            });

        })
       
    });
    return authersrouter;
}
module.exports=routerauthers;

// <%=for(i=0;i<autdet.length;i++){%>
// <h3><%=autdet[i].name%></h3>

// <%}%>