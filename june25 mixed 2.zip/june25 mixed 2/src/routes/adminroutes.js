const expresss=require("express");

const adminrouter=expresss.Router();
const bookdatae=require("../model/bookdatafile");

function router(nav){
    adminrouter.get("/",function(req,res){
        res.render("addbook",{
            nav,
            title:"library"
        })
    })
    //adminrouter.get("/add",function(req,res){
        adminrouter.post("/add",function(req,res){
         //res.send("iam added")
        var item={
            title:req.body.title,   //title:req.query.title,insted of query we have to use body in POST method because we are accessing from body not from (url)qery parameter 
            auther:req.body.auther,
            genre:req.body.genre,
            image:req.body.image
        }
        var book=bookdatae(item);
        book.save();  //saving to the database
        res.redirect("/books")   //redircting to books page like nav bar in html
        
    })
    return adminrouter;

}
module.exports=router;

